<?php
return array (
  0 => '播放器设置,/addons/dplayer/system.php',
);