<?php
$player=array (
  'ads' => 
  array (
    'status' => '1',
    'vip' => '1',
    'group' => '3',
  ),
  'aes' => 
  array (
    'status' => '0',
  ),
  'pre' => 
  array (
    'status' => '1',
    'url' => 'https://api.madouapi.com/play/02.png',
  ),
  'logo' => 
  array (
    'status' => '1',
    'url' => 'https://madouui.com/wp-content/themes/mdym/img/logo.png',
  ),
  'copyright' => 
  array (
    'status' => '1',
    'content' => '麻豆源码',
    'url' => 'https://madouui.com',
  ),
  'dp' => 
  array (
    'auto' => '1',
    'last' => '1',
    'next' => '1',
    'h5' => NULL,
  ),
);
$pre=array (
  'trysee' => 
  array (
    'status' => NULL,
    'time' => '10',
  ),
  'ads' => 
  array (
    'status' => '1',
    'time' => '60',
    'button' => '1',
    'auth' => '0',
    'group' => '3',
  ),
  'pic' => 
  array (
    'status' => '1',
    'img' => 'https://api.madouapi.com/play/03.png',
    'link' => 'https://madouui.com',
    'width' => '',
    'height' => '',
  ),
  'vod' => 
  array (
    'status' => '0',
    'url' => 'https://ckplayer-video.oss-cn-shanghai.aliyuncs.com/mp4/1_1920x1080.mp4',
    'link' => '',
  ),
);
$pause=array (
  'status' => '1',
  'pic' => 'https://api.madouapi.com/play/01.png',
  'width' => '',
  'height' => '',
  'link' => 'https://madouui.com',
);
