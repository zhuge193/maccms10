<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:35:"template/Miss/shtml/user/login.html";i:1738359074;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/include.html";i:1738359073;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/header.html";i:1738366210;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/footer.html";i:1738366878;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/gotop.html";i:1738394164;}*/ ?>
<!DOCTYPE html>
<html>
	<head> 
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1" /> 
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" /> 
		<meta name="format-detection" content="telephone=no" /> 
		<title>用户登录 - <?php echo $maccms['site_name']; ?></title> 
		<meta name="keywords" content="用户登录,<?php echo $maccms['site_keywords']; ?>" /> 
		<meta name="description" content="<?php echo $maccms['site_description']; ?>" />
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


<script src="<?php echo $maccms['path']; ?>static/js/jquery.imageupload.js"></script>
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/user.css">

	</head>
	<body>
	<div class="relative">
	<div class="z-max w-full bg-gradient-to-b from-darkest">
		<div class="sm:container flex justify-between items-center mx-auto px-4">
			<div class="lg:w-0 lg:flex-1">
				<a class="text-4xl leading-normal" href="/">
					<span style="visibility: visible;" class="font-serif">
						<img class="img" src="<?php echo $GLOBALS['config']['madou']['logo']; ?>" alt="logo" style="display: inline;">
					</span>
				</a>
			</div>
				</div>
			</div>
</div>
	<div class="sm:container mx-auto px-4 content-without-search">
		<h1 class="text-center text-2xl text-nord4 font-light mb-6">会员登录</h1>
	</div>	
	<div class="<!--madou-main-info--> madou-min-width px-4 pb-12"> 
		<div class="madou-part-case"> 
			<div class="madou-part-layout madou-back-whits"> 
				<div class="madou-user-login"> 
					<!--
					<div class="madou-list-head madou-part-rows madou-padding"> 
						<h2 class="madou-font-xvii madou-text-center">会员登录</h2> 
					</div> 
					-->
					<form class="madou-user-form madou-user-width madou-part-rows" action="" method="post" id="fm"> 
						<input class="madou-user-text madou-col-xs12 madou-input" type="text" id="user_name" name="user_name" placeholder="请输入您的账号" maxlength="30" /> 
						<input class="madou-user-text madou-col-xs12 madou-input" type="password" id="user_pwd" name="user_pwd" placeholder="请输入您的密码" maxlength="20" /> 
						<?php if($GLOBALS['config']['user']['login_verify'] == 1): ?> 
						<input class="madou-user-text madou-col-xs8 madou-input" style="border-bottom-right-radius: 0;border-top-right-radius: 0;" type="tel" id="verify" name="verify" placeholder="请输入验证码" maxlength="4" /> 
						<img class="madou-user-code madou-user-text madou-col-xs4" style="height:40px;border-radius: .375rem;border-bottom-left-radius: 0;border-top-left-radius: 0;" src="<?php echo mac_url('verify/index'); ?>" id="verify_img" onclick="this.src=this.src+'?'" title="看不清楚? 换一张！" /> 
						<?php endif; ?> 
						<span class="madou-user-tips madou-text-gules madou-padding-v madou-visible madou-col-xs12">　</span> 
						<input type="button" id="btn_submit" class="madou-subm-login madou-user-submit madou-rims-info madou-btns-info madou-btns-green madou-col-xs12" value="登录" /> 
						<a class="madou-padding madou-col-xs3 madou-text-left" href="<?php echo mac_url('user/reg'); ?>">注册账号</a>
						<?php if($GLOBALS['config']['connect']['qq']['status'] == 0 && $GLOBALS['config']['connect']['weixin']['status'] == 0): else: if($GLOBALS['config']['connect']['qq']['status'] == 1): ?> 
						<a class="madou-padding madou-col-xs3 madou-text-center" href="<?php echo mac_url('user/oauth'); ?>?type=qq">QQ登录</a> 
						<?php endif; if($GLOBALS['config']['connect']['weixin']['status'] == 1): ?> 
						<a class="madou-padding madou-col-xs3 madou-text-center" href="<?php echo mac_url('user/oauth'); ?>?type=weixin">微信登录</a> 
						<?php endif; endif; ?> 
						<a class="madou-padding madou-text-right" style="float:right" href="<?php echo mac_url('user/findpass'); ?>">忘记密码</a> 
					</form> 
				</div> 
			</div> 
		</div> 
	</div> 
	<div class="mb-5 lg:mb-10">
	<a href="#">
		<span class="sr-only">返回顶部</span>
		<svg class="w-8 h-8 mx-auto text-nord6 hover:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path>
		</svg>
	</a>
</div>
<footer aria-labelledby="footerHeading" class="sm:container mx-auto px-4">
	<div class="max-w-7xl mx-auto py-12 lg:py-16">
		<h2 id="footerHeading" class="sr-only">页尾</h2>
				</a>
				<p class="text-gray-500 text-base">
					<?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['footer']['introduce']); ?>
				</p>
	</div>
</footer>
<div style="display:none"><?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['tj']); ?></div>

<div class="mobile-bottom-nav">
    <a href="/" class="nav-item">
        <span class="icon">🏠</span>
        <span class="text">首页</span>
    </a>
    <a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="nav-item">
        <span class="icon">🎬</span>
        <span class="text">视频</span>
    </a>
    <a href="javascript:void(0);" class="nav-item">
        <span class="icon">💬</span>
        <span class="text">客服</span>
    </a>
    <a href="<?php echo mac_url('user/index'); ?>" class="nav-item">
        <span class="icon">👤</span>
        <span class="text">我的</span>
    </a>
</div>

<style>
    .mobile-bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 10px 0;
        z-index: 1000;
    }
    .nav-item {
        text-align: center;
        flex: 1;
        color: #333;
        text-decoration: none;
    }
    .icon {
        display: block;
        font-size: 20px;
    }
    .text {
        font-size: 12px;
    }
</style>

	<script type="text/javascript">
		$(function(){
			$("body").bind('keyup',function(event) {
				if(event.keyCode==13){ $('#btnLogin').click(); }
			});
			$('#btn_submit').click(function() {
				if ($('#user_name').val()  == '') { layer.msg('请输入您的账号'); $("#user_name").focus(); return false; }
				if ($('#user_pwd').val()  == '') { layer.msg('请输入您的密码'); $("#user_pwd").focus(); return false; }
				if ($('#verify').length> 0 && $('#verify').val()  == '') { layer.msg('请输入验证码'); $("#verify").focus(); return false; }

				$.ajax({
					url: "<?php echo mac_url('user/login'); ?>",
					type: "post",
					dataType: "json",
					data: $('#fm').serialize(),
					beforeSend: function () {
						$("#btn_submit").val("loading...");
					},
					success: function (r) {
						if(r.code==1){
							location.href="<?php echo mac_url('user/index'); ?>";
						}
						else{
							layer.msg(r.msg);
							$('#verify_img').click();
						}
					},
					complete: function () {
						$("#btn_submit").val("立即登录");
					}
				});

			});
		});
	</script>   
	</body>
</html>