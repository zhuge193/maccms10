<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:36:"template/Miss/shtml/actor/index.html";i:1738394164;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/header.html";i:1738366210;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/footer.html";i:1738366878;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/gotop.html";i:1738394164;}*/ ?>
<!DOCTYPE html>
<html lang="zh-Hant">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>演员库 - <?php echo $maccms['site_name']; ?></title>
		<meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>">
		<meta name="description" content="<?php echo $maccms['site_description']; ?>">
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


	</head>
	<body class="relative">
		<div class="relative">
	<div class="z-max w-full bg-gradient-to-b from-darkest">
		<div class="sm:container flex justify-between items-center mx-auto px-4">
			<div class="lg:w-0 lg:flex-1">
				<a class="text-4xl leading-normal" href="/">
					<span style="visibility: visible;" class="font-serif">
						<img class="img" src="<?php echo $GLOBALS['config']['madou']['logo']; ?>" alt="logo" style="display: inline;">
					</span>
				</a>
			</div>
				</div>
			</div>
</div>
		<div class="sm:container mx-auto px-4 content-without-search pb-12">
			<h1 class="text-center text-2xl text-nord4 font-light mb-6">演员库</h1>
			<div class="max-w-full p-4 text-nord4 bg-nord1 rounded-lg">
				<ul class="mx-auto grid grid-cols-3 gap-4 gap-y-8 sm:grid-cols-4 md:gap-6 lg:gap-8 lg:gap-y-12 xl:grid-cols-6 text-center">
					<?php $__TAG__ = '{"num":"100","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Actor")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li>
						<div class="space-y-4">
							<a href="<?php echo mac_url_actor_detail($vo); ?>" class="text-nord13">
								<div class="overflow-hidden mx-auto h-20 w-20 rounded-full lg:w-24 lg:h-24">
									<img class="object-cover object-top w-full h-full lozad" data-src="<?php echo mac_url_img($vo['actor_pic']); ?>" src="<?php echo $GLOBALS['config']['madou']['lazy']; ?>" onerror="javascript:this.src='<?php echo $GLOBALS['config']['madou']['lazy']; ?>'" alt="<?php echo $vo['actor_name']; ?>">
								</div>
							</a>
							<div class="space-y-2">
								<a href="<?php echo mac_url_actor_detail($vo); ?>" class="text-nord13">
									<h4 class="text-nord13 truncate"><?php echo $vo['actor_name']; ?></h4>
									<p class="text-nord10"><?php $__TAG__ = '{"paging":"yes","pageurl":"actor\/index","actor":"'.$vo['actor_name'].'","id":"vo2","key":"key2"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;endforeach; endif; else: echo "" ;endif; ?><?php echo $__PAGING__['record_total']; ?> 部影片</p>
								</a>
							</div>
						</div>
					</li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</div>
		</div>
		<div class="mb-5 lg:mb-10">
	<a href="#">
		<span class="sr-only">返回顶部</span>
		<svg class="w-8 h-8 mx-auto text-nord6 hover:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path>
		</svg>
	</a>
</div>
<footer aria-labelledby="footerHeading" class="sm:container mx-auto px-4">
	<div class="max-w-7xl mx-auto py-12 lg:py-16">
		<h2 id="footerHeading" class="sr-only">页尾</h2>
				</a>
				<p class="text-gray-500 text-base">
					<?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['footer']['introduce']); ?>
				</p>
	</div>
</footer>
<div style="display:none"><?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['tj']); ?></div>

<div class="mobile-bottom-nav">
    <a href="/" class="nav-item">
        <span class="icon">🏠</span>
        <span class="text">首页</span>
    </a>
    <a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="nav-item">
        <span class="icon">🎬</span>
        <span class="text">视频</span>
    </a>
    <a href="javascript:void(0);" class="nav-item">
        <span class="icon">💬</span>
        <span class="text">客服</span>
    </a>
    <a href="<?php echo mac_url('user/index'); ?>" class="nav-item">
        <span class="icon">👤</span>
        <span class="text">我的</span>
    </a>
</div>

<style>
    .mobile-bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 10px 0;
        z-index: 1000;
    }
    .nav-item {
        text-align: center;
        flex: 1;
        color: #333;
        text-decoration: none;
    }
    .icon {
        display: block;
        font-size: 20px;
    }
    .text {
        font-size: 12px;
    }
</style>

	</body>
</html>