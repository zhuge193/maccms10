<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:35:"template/Miss/shtml/vod/search.html";i:1738394166;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/header.html";i:1738366210;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/module/vodlist.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/paging.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/footer.html";i:1738366878;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/gotop.html";i:1738394164;}*/ ?>
<!DOCTYPE html>
<html lang="zh-Hant">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title><?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?><?php echo $param['tag']; ?>搜索结果 - <?php echo $maccms['site_name']; ?></title>
		<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?><?php echo $param['tag']; ?>搜索结果">
		<meta name="description" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?><?php echo $param['tag']; ?>搜索结果">
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


	</head>
	<body class="relative">
		<div class="relative">
	<div class="z-max w-full bg-gradient-to-b from-darkest">
		<div class="sm:container flex justify-between items-center mx-auto px-4">
			<div class="lg:w-0 lg:flex-1">
				<a class="text-4xl leading-normal" href="/">
					<span style="visibility: visible;" class="font-serif">
						<img class="img" src="<?php echo $GLOBALS['config']['madou']['logo']; ?>" alt="logo" style="display: inline;">
					</span>
				</a>
			</div>
				</div>
			</div>
</div>
		<div class="sm:container mx-auto px-4 content-without-search pb-12">
			<h1 class="text-center text-2xl text-nord4 mb-6"><?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?><?php echo $param['tag']; ?>的搜索结果</h1>
			<div class="flex justify-between mb-6">
				<div class="relative">
					<?php $__TAG__ = '{"num":"'.$GLOBALS['config']['madou']['typenum'].'","paging":"yes","pageurl":"vod\/search","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;endforeach; endif; else: echo "" ;endif; ?>
					<a class="text-nord6 group inline-flex items-center text-base leading-6 font-medium hover:text-primary focus:outline-none">
						<span>当前<?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?>页</span>
					</a>
				</div>
				<div class="relative">
					<a class="filter text-nord6 group inline-flex items-center text-base leading-6 font-medium hover:text-primary focus:outline-none">
						<span>排序: <?php if($param['by'] == ''||$param['by'] == 'time'): ?>最近更新<?php endif; if($param['by'] == 'hits_day'): ?>今日浏览数<?php endif; if($param['by'] == 'hits_week'): ?>本周浏览数<?php endif; if($param['by'] == 'hits_month'): ?>本月浏览数<?php endif; if($param['by'] == 'hits'): ?>总浏览数<?php endif; ?></span>
						<svg class="ml-1 h-5 w-5 text-nord6 group-hover:text-primary" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
							<path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
						</svg>
					</a>
					<div class="filterDropdown right-0 z-max origin-top-right absolute mt-2 w-56 rounded-md shadow-lg hidden">
						<div class="rounded-md text-nord0 bg-nord5 shadow-xs">
							<div class="py-1">
								<a href="<?php echo mac_url_search(['wd'=>$param['wd'],'area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'time' ],'vod'); ?>" class="block px-4 py-2 text-sm leading-5 text-nord0 hover:bg-nord4">最近更新</a>
								<a href="<?php echo mac_url_search(['wd'=>$param['wd'],'area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'hits_day' ],'vod'); ?>" class="block px-4 py-2 text-sm leading-5 text-nord0 hover:bg-nord4">今日浏览数</a>
								<a href="<?php echo mac_url_search(['wd'=>$param['wd'],'area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'hits_week' ],'vod'); ?>" class="block px-4 py-2 text-sm leading-5 text-nord0 hover:bg-nord4">本周浏览数</a>
								<a href="<?php echo mac_url_search(['wd'=>$param['wd'],'area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'hits_month' ],'vod'); ?>" class="block px-4 py-2 text-sm leading-5 text-nord0 hover:bg-nord4">本月浏览数</a>
								<a href="<?php echo mac_url_search(['wd'=>$param['wd'],'area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'hits' ],'vod'); ?>" class="block px-4 py-2 text-sm leading-5 text-nord0 hover:bg-nord4">总浏览数</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
				<?php $__TAG__ = '{"num":"'.$GLOBALS['config']['madou']['typenum'].'","paging":"yes","pageurl":"vod\/search","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<div class="thumbnail group">
	<div class="relative aspect-w-16 aspect-h-9 rounded overflow-hidden shadow-lg">
		<a href="<?php echo mac_url_vod_play($vo); ?>"><img class="lozad w-full" data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo $GLOBALS['config']['madou']['lazy']; ?>" onerror="javascript:this.src='<?php echo $GLOBALS['config']['madou']['lazy']; ?>'" alt="<?php echo $vo['vod_name']; ?>"></a>
		<?php if($GLOBALS['config']['madou']['free']['state'] != '1'): if($vo['vod_vip'] == '2'&&$vo['vod_points'] == '0'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">VIP</span></a>
    	<?php elseif($vo['vod_points'] != '0'&&$vo['vod_vip'] == '2'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo['vod_points']; ?></span></a>
    	<?php elseif($vo['vod_points'] != '0'&&$vo['vod_vip'] == '1'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo['vod_points']; ?></span></a>
    	<?php else: endif; endif; if($vo['vod_remarks'] != ''): ?>
		<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 left-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75"><?php echo $vo['vod_remarks']; ?></span></a>
		<?php endif; if($vo['vod_duration'] != ''): ?>
		<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-gray-800 bg-opacity-75"><?php echo mac_default($vo['vod_duration'],''); ?></span></a>
		<?php endif; ?>
	</div>
	<div class="my-2 text-sm text-nord4 truncate"><a class="text-secondary group-hover:text-primary" href="<?php echo mac_url_vod_play($vo); ?>"><?php echo $vo['vod_name']; ?></a></div>
</div>


				<?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
			<nav class="flex items-center justify-between mt-6">
	<div class="flex justify-between flex-1 md:hidden">
		<a <?php if($__PAGING__['page_current'] != '1'): ?>href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>"<?php endif; ?> class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-nord4 rounded-lg leading-5 bg-nord2 active:bg-nord1 transition ease-in-out duration-150">上一页</a>
		<form action="" method="GET" class="relative">
			<input type="text" name="page" value="<?php echo $__PAGING__['page_current']; ?>" class="bg-nord1 appearance-none w-28 border-2 border-nord3 rounded-lg px-3 py-2 text-nord4 leading-5 focus:outline-none focus:text-nord9 focus:bg-nord0 focus:ring-0 focus:border-nord9" maxlength="4">
			<div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
				<span class="text-gray-500 sm:text-sm">
					/ <?php echo $__PAGING__['page_total']; ?>
				</span>
			</div>
		</form>
		<a <?php if($__PAGING__['page_current'] != $__PAGING__['page_total']): ?>href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>"<?php endif; ?> class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-nord4 rounded-lg leading-5 bg-nord2 active:bg-nord1 transition ease-in-out duration-150">下一页</a>
	</div>
	<div class="hidden md:flex-1 md:flex md:items-center md:justify-center">
		<span class="relative z-0 inline-flex shadow-sm">
			<?php if($__PAGING__['page_current'] != '1'): ?>
			<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>" class="relative inline-flex items-center px-2 py-2 text-sm font-medium text-nord4 rounded-lg leading-5 hover:bg-nord1 active:bg-nord1 transition ease-in-out duration-150">
				<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
					<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"></path>
				</svg>
			</a>
			<?php endif; if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): if($__PAGING__['page_current'] == $num): ?>
			<span aria-current="page">
				<span class="relative inline-flex items-center px-4 py-2 -ml-px text-sm font-medium rounded-lg text-nord6 bg-primary cursor-default leading-5"><?php echo $num; ?></span>
			</span>
			<?php else: ?>
			<a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>" class="relative inline-flex items-center px-4 py-2 -ml-px text-sm font-medium text-nord4 leading-5 rounded-lg hover:bg-nord1 focus:z-10 focus:outline-none active:bg-nord1 transition ease-in-out duration-150"><?php echo $num; ?></a>
			<?php endif; endforeach; endif; else: echo "" ;endif; ?>
			<span aria-disabled="true">
				<span class="relative inline-flex items-center px-4 py-2 -ml-px text-sm font-medium text-nord4 cursor-default leading-5">...</span>
			</span>
			<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>" class="relative inline-flex items-center px-4 py-2 -ml-px text-sm font-medium text-nord4 leading-5 rounded-lg hover:bg-nord1 focus:z-10 focus:outline-none active:bg-nord1 transition ease-in-out duration-150"><?php echo $__PAGING__['page_total']; ?></a>
			<?php if($__PAGING__['page_current'] != $__PAGING__['page_total']): ?>
			<a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>" class="relative inline-flex items-center px-2 py-2 -ml-px text-sm font-medium text-nord4 rounded-lg leading-5 hover:bg-nord1 active:bg-nord1 transition ease-in-out duration-150" aria-label="pagination.next">
				<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
					<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
				</svg>
			</a>
			<?php endif; ?>
		</span>
	</div>
</nav>
<div class="hidden md:flex md:flex-col md:items-center md:justify-center mt-4 text-nord9 space-y-6">
	<div>使用键盘上的 ← 与 → 键来转页</div>
	<div>
		<form action="" method="GET" class="relative">
			<input type="text" name="page" value="<?php echo $__PAGING__['page_current']; ?>" class="bg-nord1 appearance-none w-28 border-2 border-nord3 rounded-lg px-3 py-2 text-nord4 leading-5 focus:outline-none focus:text-nord9 focus:bg-nord0 focus:ring-0 focus:border-nord9" maxlength="4">
			<div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
				<span class="text-gray-500 sm:text-sm" id="price-currency">/ <?php echo $__PAGING__['page_total']; ?></span>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	window.document.onkeydown = disableRefresh;
	function disableRefresh(evt) {
		evt = (evt) ? evt : window.event
		if (evt.keyCode) {
			<?php if($__PAGING__['page_current'] != '1'): ?>
			if (evt.keyCode == 37) {
				window.location.href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>";
			}
			<?php endif; if($__PAGING__['page_current'] != $__PAGING__['page_total']): ?>
			if (evt.keyCode == 39) {
				window.location.href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>";
			}
			<?php endif; ?>
		}
	}
</script>
		</div>
		<div class="mb-5 lg:mb-10">
	<a href="#">
		<span class="sr-only">返回顶部</span>
		<svg class="w-8 h-8 mx-auto text-nord6 hover:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path>
		</svg>
	</a>
</div>
<footer aria-labelledby="footerHeading" class="sm:container mx-auto px-4">
	<div class="max-w-7xl mx-auto py-12 lg:py-16">
		<h2 id="footerHeading" class="sr-only">页尾</h2>
				</a>
				<p class="text-gray-500 text-base">
					<?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['footer']['introduce']); ?>
				</p>
	</div>
</footer>
<div style="display:none"><?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['tj']); ?></div>

<div class="mobile-bottom-nav">
    <a href="/" class="nav-item">
        <span class="icon">🏠</span>
        <span class="text">首页</span>
    </a>
    <a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="nav-item">
        <span class="icon">🎬</span>
        <span class="text">视频</span>
    </a>
    <a href="javascript:void(0);" class="nav-item">
        <span class="icon">💬</span>
        <span class="text">客服</span>
    </a>
    <a href="<?php echo mac_url('user/index'); ?>" class="nav-item">
        <span class="icon">👤</span>
        <span class="text">我的</span>
    </a>
</div>

<style>
    .mobile-bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 10px 0;
        z-index: 1000;
    }
    .nav-item {
        text-align: center;
        flex: 1;
        color: #333;
        text-decoration: none;
    }
    .icon {
        display: block;
        font-size: 20px;
    }
    .text {
        font-size: 12px;
    }
</style>

	</body>
</html>
