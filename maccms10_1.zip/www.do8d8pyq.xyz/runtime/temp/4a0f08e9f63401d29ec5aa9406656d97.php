<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:39:"template/Miss/shtml/user/ajax_info.html";i:1738359076;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/include.html";i:1738359073;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:64:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/head.html";i:1738359073;s:64:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/foot.html";i:1738359079;}*/ ?>
<!DOCTYPE html>
<html>
	<head> 
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1" /> 
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" /> 
		<meta name="format-detection" content="telephone=no" /> 
		<title>个人中心 - <?php echo $maccms['site_name']; ?></title> 
		<meta name="keywords" content="个人中心,<?php echo $maccms['site_keywords']; ?>" /> 
		<meta name="description" content="<?php echo $maccms['site_description']; ?>" />
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


<script src="<?php echo $maccms['path']; ?>static/js/jquery.imageupload.js"></script>
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/user.css">

	</head>
	<body class="madou-min-width">
	
	<div class="madou-main-info madou-min-width"> 
		<div class="madou-part-case"> 
			<div class="madou-user-head madou-margin-top madou-back-whits"> 
				<div class="madou-list-pics madou-lazy madou-part-5by2 madou-part-rows" style="background:url(<?php echo $maccms['path']; ?>static/images/user.jpg);"> 
					<div class="madou-part-core madou-text-center"> 
					<div class="madou-user-image" data-role="<?php echo mac_url('user/portrait'); ?>"> 
						<img class="face madou-user-avat madou-part-roun" src="<?php echo mac_url_img(mac_default($obj['user_portrait'],'static/images/touxiang.png')); ?>?v=<?php echo time(); ?>" /> 
					</div> 
					<span class="madou-visible madou-text-white madou-padding"><?php echo $obj['user_name']; ?></span> 
					</div> 
				</div> 
				<div class="madou-padding madou-part-rows madou-back-whits madou-hide-md"> 
					<ul class="madou-user-brief madou-part-rows madou-back-whits"> 
						<li class="madou-padding-x madou-text-center madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_points']; ?></span> <span class="madou-visible">我的积分</span> </li> 
						<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['group']['group_name']; ?></span> <span class="madou-visible">我的等级</span> </li> 
						<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_money']; ?></span> <span class="madou-visible">我的余额</span> </li> 
					</ul> 
				</div> 
			</div> 
			<div class="madou-part-rows"> 
				<div class="madou-main-left madou-col-xs12 madou-col-md4 madou-col-lg3 madou-show-md-block"> 
					<div class="madou-part-layout madou-back-whits"> 
						<div class="madou-user-title madou-list-head madou-part-rows madou-padding madou-line-bottom"> 
							<h2 class="madou-font-xvi madou-padding">我的资料</h2> 
							<ul class="madou-part-tips madou-padding"> 
								<li class="madou-padding"> <a class="madou-more" href="<?php echo mac_url('user/index'); ?>">返回</a> </li> 
							</ul> 
						</div> 
						<ul class="madou-user-list madou-part-rows madou-back-whits"> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">用户名</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo $obj['user_name']; ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div>
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">所属会员组</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo $obj['group']['group_name']; ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">到期时间</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_default(mac_day($obj['user_end_time']),'无限期'); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">账户积分</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo $obj['user_points']; ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">QQ号码</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_default($obj['user_qq'],'未填写'); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">邮件地址</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_default($obj['user_email'],'未填写'); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">联系手机</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_default($obj['user_phone'],'未填写'); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">注册时间</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_default(mac_day($obj['user_reg_time']),'未知'); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">登录时间</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo mac_day($obj['user_login_time']); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">登录IP</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo long2ip($obj['user_login_ip']); ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">登录次数</span> 
								<span class="madou-col-xs7 madou-col-sm8 madou-part-eone"><?php echo $obj['user_login_num']; ?></span> 
								<span class="madou-col-xs1 madou-col-sm1 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> 
								</div> 
							</li> 
							<?php if($GLOBALS['config']['user']['invite_reg_points'] >= 0): ?>
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">推广注册</span> 
								<span class="madou-col-xs6 madou-col-sm8 madou-part-eone"><input class="madou-visible madou-input" value="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?>?uid=<?php echo $obj['user_id']; ?>" readonly="readonly"/></span> 
								<span class="madou-col-xs2 madou-col-sm1 madou-part-eone madou-text-right" style="cursor:pointer;color:#fe628e;" id="share" data-clipboard-text="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?>?uid=<?php echo $obj['user_id']; ?>">复制</span> 
								</div> 
							</li> 
							<?php endif; if($GLOBALS['config']['user']['invite_visit_points'] > 0): ?>
							<li class="madou-padding-x madou-part-rows madou-line-bottom"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm3 madou-part-eone">推广访问</span> 
								<span class="madou-col-xs6 madou-col-sm8 madou-part-eone"><input class="madou-visible madou-input" value="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?><?php echo mac_url('user/visit'); ?>?uid=<?php echo $obj['user_id']; ?>" readonly="readonly"/></span> 
								<span class="madou-col-xs2 madou-col-sm1 madou-part-eone madou-text-right" style="cursor:pointer;color:#fe628e;" id="share" data-clipboard-text="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?><?php echo mac_url('user/visit'); ?>?uid=<?php echo $obj['user_id']; ?>">复制</span> 
								</div> 
							</li>
							<?php endif; ?> 
						</ul> 
					</div> 
				</div> 
			</div> 
		</div> 
	</div> 
	
	<script>
		$(".face").imageUpload({
			formAction: "<?php echo mac_url('user/portrait'); ?>",
			inputFileName:'file',
			browseButtonValue: '',
			browseButtonClass:'btn btn-default btn-xs madou-user-alter madou-part-roun madou-icon-font madou-icon-xiugai',
			automaticUpload: true,
			hideDeleteButton: true,
			hover:true
		})
		$(".jQuery-image-upload-controls").mouseenter(function(){
			$(".jQuery-image-upload-controls").css("display","block");
		});
		$(".jQuery-image-upload-controls").mouseleave(function(){
			$(".jQuery-image-upload-controls").css("display","none");
		});
		$(".face").on("imageUpload.uploadFailed", function (ev, err) {
			layer.msg(err);
		});
	</script>  
	</body>
</html>