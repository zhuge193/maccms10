<?php if (!defined('THINK_PATH')) exit(); /*a:9:{s:36:"template/Miss/shtml/index/index.html";i:1738362314;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/header.html";i:1738366210;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/index/search.html";i:1738394164;s:64:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/index/new.html";i:1738394164;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/module/vodlist.html";i:1738394164;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/index/classfiy.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/footer.html";i:1738366878;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/gotop.html";i:1738394164;}*/ ?>
<!DOCTYPE html>
<html lang="zh-Hant">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title><?php echo $maccms['site_name']; ?></title>
		<meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>">
		<meta name="description" content="<?php echo $maccms['site_description']; ?>">
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


	</head>
	<body class="relative">
	    		<div class="relative">
	<div class="z-max w-full bg-gradient-to-b from-darkest">
		<div class="sm:container flex justify-between items-center mx-auto px-4">
			<div class="lg:w-0 lg:flex-1">
				<a class="text-4xl leading-normal" href="/">
					<span style="visibility: visible;" class="font-serif">
						<img class="img" src="<?php echo $GLOBALS['config']['madou']['logo']; ?>" alt="logo" style="display: inline;">
					</span>
				</a>
			</div>
				</div>
			</div>
</div>
		<div class="is-home content-without-search pb-12">
			<div class="flex flex-col justify-center content-center text-center py-16">
	<div class="container mx-auto px-4 max-w-xl">
		<h1 class="text-3xl tracking-tight leading-10 font-serif text-zinc-50 sm:text-4xl sm:leading-none mb-8" style="visibility: visible;">
			搜索你想看的<span class="text-primary">视频</span>
		</h1>
		<form class="w-full mx-auto" method="get" action="<?php echo mac_url('vod/search'); ?>">
			<div class="flex rounded-md shadow-sm w-full mx-auto">
				<div class="relative flex items-stretch grow focus-within:z-10">
					<input name="wd" type="text" class="block w-full rounded-none rounded-l-md p-3 border border-gray-300 transition ease-in-out duration-150 sm:leading-5 focus:outline-none focus:border-primary focus:ring focus:ring-nord11 focus:ring-opacity-50 placeholder-gray-400" placeholder="搜一搜" maxlength="50">
				</div>
				<button class="-ml-px relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm leading-5 font-medium rounded-r-md text-gray-700 bg-gray-50 hover:text-gray-500 hover:bg-white focus:outline-none focus:ring-blue-500 focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
					<svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
					</svg>
					<span class="ml-2 w-full">搜索</span>
				</button>
			</div>
		</form>
	</div>
</div>
			<div class="sm:container mx-auto mb-4 px-4">
	<div class="flex items-center justify-between pt-10 pb-6">
		<div class="flex-1 min-w-0">
			<h2 class="text-2xl font-bold leading-7 text-nord6 sm:text-3xl sm:truncate">最近更新</h2>
		</div>
		<div class="flex">
			<a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="text-nord4 hover:text-primary">更多<svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a>
		</div>
	</div>
	<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
		<?php $__TAG__ = '{"num":"'.$GLOBALS['config']['madou']['newnum'].'","by":"time","order":"desc","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
		<div class="thumbnail group">
	<div class="relative aspect-w-16 aspect-h-9 rounded overflow-hidden shadow-lg">
		<a href="<?php echo mac_url_vod_play($vo); ?>"><img class="lozad w-full" data-src="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo $GLOBALS['config']['madou']['lazy']; ?>" onerror="javascript:this.src='<?php echo $GLOBALS['config']['madou']['lazy']; ?>'" alt="<?php echo $vo['vod_name']; ?>"></a>
		<?php if($GLOBALS['config']['madou']['free']['state'] != '1'): if($vo['vod_vip'] == '2'&&$vo['vod_points'] == '0'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">VIP</span></a>
    	<?php elseif($vo['vod_points'] != '0'&&$vo['vod_vip'] == '2'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo['vod_points']; ?></span></a>
    	<?php elseif($vo['vod_points'] != '0'&&$vo['vod_vip'] == '1'): ?>
    	<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo['vod_points']; ?></span></a>
    	<?php else: endif; endif; if($vo['vod_remarks'] != ''): ?>
		<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 left-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75"><?php echo $vo['vod_remarks']; ?></span></a>
		<?php endif; if($vo['vod_duration'] != ''): ?>
		<a href="<?php echo mac_url_vod_play($vo); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-gray-800 bg-opacity-75"><?php echo mac_default($vo['vod_duration'],''); ?></span></a>
		<?php endif; ?>
	</div>
	<div class="my-2 text-sm text-nord4 truncate"><a class="text-secondary group-hover:text-primary" href="<?php echo mac_url_vod_play($vo); ?>"><?php echo $vo['vod_name']; ?></a></div>
</div>


		<?php endforeach; endif; else: echo "" ;endif; ?>
	</div>
</div>
			<?php $__TAG__ = '{"ids":"'.$GLOBALS['config']['madou']['index'].'","order":"asc","by":"sort","id":"vo1","key":"key1"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>
<div class="sm:container mx-auto mb-4 px-4">
	<div class="flex items-center justify-between pt-10 pb-6">
		<div class="flex-1 min-w-0">
			<h2 class="text-2xl font-bold leading-7 text-nord6 sm:text-3xl sm:truncate"><?php echo $vo1['type_name']; ?></h2>
		</div>
		<div class="flex">
			<a href="<?php echo mac_url_type($vo1); ?>" class="text-nord4 hover:text-primary">更多<svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></a>
		</div>
	</div>
	<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
		<?php $__TAG__ = '{"num":"'.$GLOBALS['config']['madou']['indexnum'].'","type":"'.$vo1['type_id'].'","order":"desc","by":"time","id":"vo2","key":"key2"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
		<div class="thumbnail group">
			<div class="relative aspect-w-16 aspect-h-9 rounded overflow-hidden shadow-lg">
				<a href="<?php echo mac_url_vod_play($vo2); ?>"><img class="lozad w-full" data-src="<?php echo mac_url_img($vo2['vod_pic']); ?>" src="<?php echo $GLOBALS['config']['madou']['lazy']; ?>" onerror="javascript:this.src='<?php echo $GLOBALS['config']['madou']['lazy']; ?>'" alt="<?php echo $vo2['vod_name']; ?>"></a>
				<?php if($GLOBALS['config']['madou']['free']['state'] != '1'): if($vo2['vod_vip'] == '2'&&$vo2['vod_points'] == '0'): ?>
            	<a href="<?php echo mac_url_vod_play($vo2); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">VIP</span></a>
            	<?php elseif($vo2['vod_points'] != '0'&&$vo2['vod_vip'] == '2'): ?>
            	<a href="<?php echo mac_url_vod_play($vo2); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo2['vod_points']; ?></span></a>
            	<?php elseif($vo2['vod_points'] != '0'&&$vo2['vod_vip'] == '1'): ?>
            	<a href="<?php echo mac_url_vod_play($vo2); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75 box-tag vip">$<?php echo $vo2['vod_points']; ?></span></a>
            	<?php else: endif; endif; if($vo2['vod_remarks'] != ''): ?>
				<a href="<?php echo mac_url_vod_play($vo2); ?>"><span class="absolute bottom-1 left-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-red-800 bg-opacity-75"><?php echo $vo2['vod_remarks']; ?></span></a>
				<?php endif; if($vo2['vod_duration'] != ''): ?>
				<a href="<?php echo mac_url_vod_play($vo2); ?>"><span class="absolute bottom-1 right-1 rounded-lg px-2 py-1 text-xs text-nord5 bg-gray-800 bg-opacity-75"><?php echo mac_default($vo2['vod_duration'],''); ?></span></a>
				<?php endif; ?>
			</div>
			<div class="my-2 text-sm text-nord4 truncate"><a class="text-secondary group-hover:text-primary" href="<?php echo mac_url_vod_play($vo2); ?>"><?php echo $vo2['vod_name']; ?></a></div>
		</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</div>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<div class="mb-5 lg:mb-10">
	<a href="#">
		<span class="sr-only">返回顶部</span>
		<svg class="w-8 h-8 mx-auto text-nord6 hover:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path>
		</svg>
	</a>
</div>
<footer aria-labelledby="footerHeading" class="sm:container mx-auto px-4">
	<div class="max-w-7xl mx-auto py-12 lg:py-16">
		<h2 id="footerHeading" class="sr-only">页尾</h2>
				</a>
				<p class="text-gray-500 text-base">
					<?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['footer']['introduce']); ?>
				</p>
	</div>
</footer>
<div style="display:none"><?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['tj']); ?></div>

<div class="mobile-bottom-nav">
    <a href="/" class="nav-item">
        <span class="icon">🏠</span>
        <span class="text">首页</span>
    </a>
    <a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="nav-item">
        <span class="icon">🎬</span>
        <span class="text">视频</span>
    </a>
    <a href="javascript:void(0);" class="nav-item">
        <span class="icon">💬</span>
        <span class="text">客服</span>
    </a>
    <a href="<?php echo mac_url('user/index'); ?>" class="nav-item">
        <span class="icon">👤</span>
        <span class="text">我的</span>
    </a>
</div>

<style>
    .mobile-bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 10px 0;
        z-index: 1000;
    }
    .nav-item {
        text-align: center;
        flex: 1;
        color: #333;
        text-decoration: none;
    }
    .icon {
        display: block;
        font-size: 20px;
    }
    .text {
        font-size: 12px;
    }
</style>

	</body>
</html>
