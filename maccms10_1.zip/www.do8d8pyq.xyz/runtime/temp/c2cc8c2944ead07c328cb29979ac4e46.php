<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:36:"template/Miss/shtml/user/reward.html";i:1738359076;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/include.html";i:1738359073;s:69:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/include.html";i:1738394164;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/header.html";i:1738366210;s:64:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/user/menu.html";i:1738359074;s:68:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/footer.html";i:1738366878;s:67:"/www/wwwroot/www.do8d8pyq.xyz/template/Miss/shtml/system/gotop.html";i:1738394164;}*/ ?>
<!DOCTYPE html>
<html>
	<head> 
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1" /> 
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" /> 
		<meta name="format-detection" content="telephone=no" /> 
		<title>分销记录 - <?php echo $maccms['site_name']; ?></title> 
		<meta name="keywords" content="分销记录,<?php echo $maccms['site_keywords']; ?>" /> 
		<meta name="description" content="<?php echo $maccms['site_description']; ?>" />
		<meta name="author" content="MaDouYM">
<link rel="icon" type="image/x-icon" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?php echo $maccms['path']; ?>MDassets/img/favicon.png">
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/app.css">
<script src="<?php echo $maccms['path']; ?>static/js/jquery.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/set.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/app.js"></script>
<script src="<?php echo $maccms['path']; ?>MDassets/js/lang.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
<?php if($GLOBALS['config']['madou']['debug']['state'] == 1): ?>
<script>DisableDevtool({})</script>
<?php endif; ?>


<script src="<?php echo $maccms['path']; ?>static/js/jquery.imageupload.js"></script>
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>MDassets/css/user.css">

	</head>
	<body class="madou-min-width">
	<div class="relative">
	<div class="z-max w-full bg-gradient-to-b from-darkest">
		<div class="sm:container flex justify-between items-center mx-auto px-4">
			<div class="lg:w-0 lg:flex-1">
				<a class="text-4xl leading-normal" href="/">
					<span style="visibility: visible;" class="font-serif">
						<img class="img" src="<?php echo $GLOBALS['config']['madou']['logo']; ?>" alt="logo" style="display: inline;">
					</span>
				</a>
			</div>
				</div>
			</div>
</div>   
	<div class="madou-main-info madou-min-width"> 
		<div class="madou-part-case"> 
			<div class="madou-user-head madou-margin-top madou-back-whits"> 
				<div class="madou-list-pics madou-lazy madou-part-5by2 madou-part-rows" style="background:url(<?php echo $maccms['path']; ?>static/images/user.jpg);"> 
					<div class="madou-part-core madou-text-center"> 
					<div class="madou-user-image" data-role="<?php echo mac_url('user/portrait'); ?>"> 
						<img class="face madou-user-avat madou-part-roun" src="<?php echo mac_url_img(mac_default($obj['user_portrait'],'static/images/touxiang.png')); ?>?v=<?php echo time(); ?>" /> 
					</div> 
					<span class="madou-visible madou-text-white madou-padding"><?php echo $obj['user_name']; ?></span> 
					</div> 
				</div> 
				<div class="madou-padding madou-part-rows madou-back-whits madou-hide-md"> 
					<ul class="madou-user-brief madou-part-rows madou-back-whits"> 
						<li class="madou-padding-x madou-text-center madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_points']; ?></span> <span class="madou-visible">我的积分</span> </li> 
						<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['group']['group_name']; ?></span> <span class="madou-visible">我的等级</span> </li> 
						<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_money']; ?></span> <span class="madou-visible">我的余额</span> </li> 
					</ul> 
				</div> 
			</div> 
			<div class="madou-part-rows"> 
				<div class="madou-main-left madou-col-xs12 madou-col-md4 madou-col-lg3 madou-hide-xs madou-hide-sm madou-show-md-block">
				<div class="madou-part-layout madou-back-whits madou-margin-right madou-hide-xs madou-hide-sm madou-show-md-block"> 
	<ul class="madou-user-brief madou-part-rows madou-back-whits"> 
		<li class="madou-padding-x madou-text-center madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_points']; ?></span> <span class="madou-visible">我的积分</span> </li> 
		<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['group']['group_name']; ?></span> <span class="madou-visible">我的等级</span> </li> 
		<li class="madou-padding-x madou-text-center madou-line-left madou-col-xs4"> <span class="madou-visible madou-text-gules"><?php echo $obj['user_money']; ?></span> <span class="madou-visible">我的余额</span> </li> 
	</ul> 
</div> 
<div class="madou-part-layout madou-back-whits madou-margin-right"> 
	<ul class="madou-user-list madou-part-rows madou-back-whits"> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom madou-hide-md"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/ajax_info'); ?>"> <span class="madou-col-xs4 madou-part-eone">我的资料</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom madou-hide madou-show-md-block"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/index'); ?>"> <span class="madou-col-xs4 madou-part-eone">我的资料</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/info'); ?>"> <span class="madou-col-xs4 madou-part-eone">修改资料</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/favs'); ?>"> <span class="madou-col-xs4 madou-part-eone">我的收藏</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/plays'); ?>"> <span class="madou-col-xs4 madou-part-eone">播放记录</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li>  
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/buy'); ?>"> <span class="madou-col-xs4 madou-part-eone">卡密激活</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/orders'); ?>"> <span class="madou-col-xs4 madou-part-eone">充值记录</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/reward'); ?>"> <span class="madou-col-xs4 madou-part-eone">三级分销</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li> 
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/plog'); ?>"> <span class="madou-col-xs4 madou-part-eone">积分记录</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li>
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/cash'); ?>"> <span class="madou-col-xs4 madou-part-eone">提现记录</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li>
		<li class="madou-padding-x madou-part-rows madou-line-bottom"> <a class="madou-tabs-title madou-visible madou-font-xvi madou-part-rows" href="<?php echo mac_url('user/upgrade'); ?>"> <span class="madou-col-xs4 madou-part-eone">升级会员</span> <span class="madou-col-xs8 madou-part-eone madou-text-right"><i class="madou-icon-font madou-icon-you"></i></span> </a> </li>
		<div class="madou-part-rows madou-padding-top"></div> 
		<li class="madou-padding-x madou-part-rows"> <a class="madou-rims-info madou-btns-info madou-btns-green madou-col-xs12" href="<?php echo mac_url('user/logout'); ?>">退出</a> </li> 
	</ul> 
</div> 
				</div> 
				<div class="madou-main-right madou-col-xs12 madou-col-md8 madou-col-lg9"> 
					<div class="madou-part-layout madou-back-whits"> 
						<div class="madou-user-title madou-list-head madou-part-rows madou-padding madou-line-bottom"> 
							<h2 class="madou-font-xvi madou-padding"><a class="<?php if($param['level'] == ''): ?>madou-text-green<?php endif; ?> madou-more" href="<?php echo mac_url('user/reward'); ?>">一级下线</a>&nbsp;&nbsp;<a class="<?php if($param['level'] == '2'): ?>madou-text-green<?php endif; ?> madou-more" href="<?php echo mac_url('user/reward'); ?>?level=2">二级下线</a>&nbsp;&nbsp;<a class="<?php if($param['level'] == '3'): ?>madou-text-green<?php endif; ?> madou-more" href="<?php echo mac_url('user/reward'); ?>?level=3">三级下线</a></h2> 
							<ul class="madou-part-tips madou-padding"> 
								<li class="madou-padding"> <a class="madou-more" href="<?php echo mac_url('user/index'); ?>">返回</a> </li> 
							</ul> 
						</div> 
						<ul class="madou-user-list madou-part-rows madou-back-whits"> 
							<li class="madou-padding-x madou-part-rows"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone">编号</span> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone">会员</span> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone madou-text-right">时间</span>  
								</div> 
							</li> 
							<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?> 
							<li class="madou-padding-x madou-part-rows madou-line-top"> 
								<div class="madou-user-input madou-visible madou-font-xvi madou-part-rows"> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone"><?php echo $vo['user_id']; ?></span> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone"><?php echo $vo['user_name']; ?></span> 
								<span class="madou-col-xs4 madou-col-sm4 madou-part-eone madou-text-right"><?php echo mac_day($vo['user_reg_time']); ?></span> 
								</div> 
							</li> 
							<?php endforeach; endif; else: echo "" ;endif; if($__PAGING__['page_total']>1): ?> 
							<div class="madou-page-info madou-text-center"> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-xs-inline<?php if($__PAGING__['page_current']==1): ?> madou-btns-disad<?php endif; ?>" href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a> 
								<a class="madou-btns-info madou-rims-info<?php if($__PAGING__['page_current']==1): ?> madou-btns-disad<?php endif; ?>" href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a> <?php if($__PAGING__['page_current']>3): ?> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-sm-inline" href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">1</a> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-sm-inline madou-btns-disad" href="javascript:;">...</a> <?php endif; if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-sm-inline<?php if($__PAGING__['page_current']==$num): ?> madou-btns-green<?php endif; ?>" href="<?php if($__PAGING__['page_current']==$num): ?>javascript:;<?php else: ?><?php echo mac_url_page($__PAGING__['page_url'],$num); endif; ?>"><?php echo $num; ?></a> <?php endforeach; endif; else: echo "" ;endif; if($__PAGING__['page_current']<($__PAGING__['page_total']-2)): ?> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-sm-inline madou-btns-disad" href="javascript:;">...</a> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-sm-inline" href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>"><?php echo $__PAGING__['page_total']; ?></a> <?php endif; ?> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-xs-inline" href="javascript:;"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></a> 
								<a class="madou-btns-info madou-rims-info<?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> madou-btns-disad<?php endif; ?>" href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a> 
								<a class="madou-btns-info madou-rims-info madou-hide madou-show-xs-inline<?php if($__PAGING__['page_current']==$__PAGING__['page_total']): ?> madou-btns-disad<?php endif; ?>" href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a> 
							</div> 
							<?php endif; if($__PAGING__['record_total']!=0): ?> 
							<script type="text/javascript">
							if(document.getElementById('madou-now')) document.getElementById('madou-now').innerHTML='<?php echo $__PAGING__['page_current']; ?>';
							if(document.getElementById('madou-count')) document.getElementById('madou-count').innerHTML='<?php echo $__PAGING__['record_total']; ?>';
							</script> 
							<?php endif; ?> 
						</ul> 
					</div> 
				</div> 
			</div> 
		</div> 
	</div> 
	<div class="mb-5 lg:mb-10">
	<a href="#">
		<span class="sr-only">返回顶部</span>
		<svg class="w-8 h-8 mx-auto text-nord6 hover:text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z"></path>
		</svg>
	</a>
</div>
<footer aria-labelledby="footerHeading" class="sm:container mx-auto px-4">
	<div class="max-w-7xl mx-auto py-12 lg:py-16">
		<h2 id="footerHeading" class="sr-only">页尾</h2>
				</a>
				<p class="text-gray-500 text-base">
					<?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['footer']['introduce']); ?>
				</p>
	</div>
</footer>
<div style="display:none"><?php echo htmlspecialchars_decode($GLOBALS['config']['madou']['tj']); ?></div>

<div class="mobile-bottom-nav">
    <a href="/" class="nav-item">
        <span class="icon">🏠</span>
        <span class="text">首页</span>
    </a>
    <a href="<?php echo mac_url('label/rank',['by'=>'time']); ?>" class="nav-item">
        <span class="icon">🎬</span>
        <span class="text">视频</span>
    </a>
    <a href="javascript:void(0);" class="nav-item">
        <span class="icon">💬</span>
        <span class="text">客服</span>
    </a>
    <a href="<?php echo mac_url('user/index'); ?>" class="nav-item">
        <span class="icon">👤</span>
        <span class="text">我的</span>
    </a>
</div>

<style>
    .mobile-bottom-nav {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        display: flex;
        justify-content: space-around;
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 10px 0;
        z-index: 1000;
    }
    .nav-item {
        text-align: center;
        flex: 1;
        color: #333;
        text-decoration: none;
    }
    .icon {
        display: block;
        font-size: 20px;
    }
    .text {
        font-size: 12px;
    }
</style>

	<script>
		$(".face").imageUpload({
			formAction: "<?php echo url('user/portrait'); ?>",
			inputFileName:'file',
			browseButtonValue: '',
			browseButtonClass:'btn btn-default btn-xs madou-user-alter madou-part-roun madou-icon-font madou-icon-xiugai',
			automaticUpload: true,
			hideDeleteButton: true,
			hover:true
		})
		$(".jQuery-image-upload-controls").mouseenter(function(){
			$(".jQuery-image-upload-controls").css("display","block");
		});
		$(".jQuery-image-upload-controls").mouseleave(function(){
			$(".jQuery-image-upload-controls").css("display","none");
		});
		$(".face").on("imageUpload.uploadFailed", function (ev, err) {
			layer.msg(err);
		});
	</script>  
	</body>
</html>